---
name: juejin-auto-publisher
description: 掘金自动发帖与 SEO 优化技能。当用户说"发掘金"、"发布文章"、"写技术博客"、"推送到掘金"、"掘金 SEO"、"批量发布"、或需要定期在掘金社区发布技术文章时触发。本技能支持文章自动生成（基于 GitHub 项目/技术文档/日报数据）、多标签分类、SEO 关键词优化、自动配图建议，并支持定时发布（每日/每周）和多账号管理。适用于技术博主、内容创作者、AI 工具推广者。搭配 github-trending-digest 可自动将每日趋势报告发布到掘金。
paid: true
price: ¥39 / $5.49 USD
payment: https://paypal.me/lingxiagent/399
payment_cn: 联系 Telegram @diquchaxun78_bot 或微信购买
version: 1.0.0
author: 灵犀
---
# 掘金自动发帖器 — Juejin Auto Publisher

## 💰 付费说明

本技能为付费技能（¥39 / $5.49 USD，永久授权）。

**包含内容：**
- 文章自动生成（Markdown / 富文本双格式）
- SEO 关键词自动优化（标题/摘要/标签）
- 多标签分类 + 热门标签推荐
- 自动配图（根据文章主题抓取相关 Unsplash 图片）
- 定时发布（每日 09:00 / 每周一 10:00）
- 多账号管理（cookie 会话持久化）
- 每日/每周发布统计报表

**获取方式：** [PayPal 付款](https://paypal.me/lingxiagent/399) 后联系 Telegram [@diquchaxun78_bot](https://t.me/diquchaxun78_bot) 发送付款截图获取完整技能包。

---

## 快速开始

### Step 1：安装依赖

```bash
pip install requests beautifulsoup4 markdown Pillow schedule jinja2
```

### Step 2：配置掘金 Cookie

```bash
# 浏览器登录掘金后，F12 → Application → Cookies → 复制 cookie 值
export JUEJIN_COOKIE="your_cookie_here"
```

### Step 3：发布文章

```bash
# 发布本地 Markdown 文件
python3 juejin_publisher.py --file my-article.md

# 直接指定内容
python3 juejin_publisher.py --title "Python 异步编程实战" --content "# Python 异步..." --tags python,异步,教程

# 从 GitHub Trending 日报自动发布
python3 juejin_publisher.py --from-report REPORT.md --category 技术 --auto-tag
```

---

## 核心功能

### ✍️ 文章发布

```bash
# 基础发布
python3 juejin_publisher.py --file article.md

# 带标签和分类
python3 juejin_publisher.py \
  --title "AI Agent 开发者的全栈工具箱" \
  --tags AI,Agent,GitHub,自动化 \
  --category 技术 \
  --cover "https://images.unsplash.com/..." \
  --draft           # 仅保存为草稿，不发布
```

### 🤖 AI 内容增强

```bash
# 自动生成摘要 + SEO 优化
python3 juejin_publisher.py \
  --file article.md \
  --ai-summary \
  --ai-keywords \
  --auto-tag

# SEO 关键词推荐
python3 juejin_publisher.py --keywords "Python AI Agent 自动化" --seo-recommend
```

### ⏰ 定时发布

```python
# 每日 09:00 自动发布
from juejin_scheduler import DailyPublisher
pub = DailyPublisher(
    cookie=os.environ["JUEJIN_COOKIE"],
    schedule_time="09:00",
    timezone="Asia/Shanghai",
)
pub.add_rule(pattern="*.md", category="技术", tags=["日报","AI"])
pub.start()
```

---

## SEO 优化配置

```json
{
  "seo": {
    "title_pattern": "{keyword}实战 | 2026年最新指南",
    "meta_description_length": 120,
    "tags_limit": 5,
    "hot_tags": ["AI", "GitHub", "Python", "JavaScript", "工具推荐"],
    "forbidden_words": ["微信", "QQ群", "私聊"],
    "cover_required": true
  },
  "publish": {
    "category_default": "技术",
    "auto_tag": true,
    "ai_summary": true,
    "status": "published"
  }
}
```

---

## 常见使用场景

| 场景 | 命令 |
|---|---|
| 发掘金文章 | `--file article.md --publish` |
| 发布草稿（先审后发） | `--file article.md --draft` |
| AI 自动生成摘要 | `--file article.md --ai-summary` |
| 批量发日报 | `--batch --dir ./reports/` |
| 每日定时发 | `--schedule daily --time 09:00` |
| 统计本月发布 | `--stats --month 2026-08` |
| SEO 关键词推荐 | `--keywords Python异步编程 --seo-recommend` |

---

## 多账号管理

```bash
# 添加账号
python3 juejin_publisher.py --account-add --name myblog --cookie "cookie1"

# 轮换发布（避免频繁发布被限流）
python3 juejin_publisher.py --file article.md --account myblog --rotate

# 列出所有账号
python3 juejin_publisher.py --account-list
```

---

## 发布状态码说明

| 状态码 | 含义 | 处理 |
|---|---|---|
| 200 | 发布成功 | ✅ |
| 401 | Cookie 失效 | 重新登录获取 |
| 429 | 请求过于频繁 | 等待 60 秒重试 |
| 500 | 服务器错误 | 自动重试 3 次 |

---

## 故障排除

**Q: 报 401 Unauthorized？**
→ 掘金 cookie 过期，请重新登录掘金并更新 `JUEJIN_COOKIE`

**Q: 429 Too Many Requests？**
→ 两次发布间隔至少 30 分钟，或用 `--rotate` 切换账号

**Q: 标签不显示？**
→ 掘金最多 5 个标签，请检查 `tags_limit` 配置

**Q: 草稿如何发布？**
→ `python3 juejin_publisher.py --publish-draft <draft_id>`

---

*版本 1.0.0 · 灵犀 AI · 2026-08*
