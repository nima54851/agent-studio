#!/usr/bin/env python3
"""
掘金自动发帖器 — Juejin Auto Publisher
支持 Markdown/富文本发布、AI SEO 优化、定时任务
"""
import os, sys, json, argparse, time, hashlib
from datetime import datetime, timezone, timedelta

try:
    import requests
except ImportError:
    print("❌ 需要 requests: pip install requests"); sys.exit(1)

JUEJIN_API  = "https://api.juejin.cn"
JUEJIN_WEB  = "https://juejin.cn"
COOKIE      = os.environ.get("JUEJIN_COOKIE", "")
AI_API_KEY  = os.environ.get("AI_API_KEY", "")

CONFIG = {
    "seo": {
        "title_pattern": "{keyword}实战 | 2026技术指南",
        "meta_description_length": 120,
        "tags_limit": 5,
        "hot_tags": ["AI", "GitHub", "Python", "JavaScript", "工具推荐", "自动化", "教程"],
        "cover_required": True,
    },
    "publish": {
        "category_default": "技术",
        "auto_tag": True,
        "ai_summary": True,
        "status": "published",
    },
    "accounts": {},
}

CATEGORIES = {
    "技术":      "6809637769959178254",
    "AI":        "6809637776995077134",
    "前端":      "6809637771251451918",
    "后端":      "6809637771510169636",
    "Android":   "6809637771261373700",
    "iOS":       "6809637768479165444",
    "开发工具":  "6809637770061251597",
}

def load_config():
    path = os.path.expanduser("~/.juejin_publisher_config.json")
    if os.path.exists(path):
        with open(path) as f:
            return json.load(f)
    return CONFIG

def save_config(cfg):
    path = os.path.expanduser("~/.juejin_publisher_config.json")
    with open(path, "w") as f:
        json.dump(cfg, f, indent=2, ensure_ascii=False)

def headers(cookie=None):
    c = cookie or COOKIE
    return {
        "Cookie": c,
        "Content-Type": "application/json",
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36",
        "Referer": "https://juejin.cn/editor",
    }

def check_login(cookie=None):
    """验证 cookie 是否有效"""
    c = cookie or COOKIE
    if not c:
        return False, "Cookie 未设置"
    r = requests.get(
        f"{JUEJIN_API}/user_api/v1/user/info",
        headers=headers(c),
        timeout=10
    )
    if r.status_code == 200 and r.json().get("err_no") == 0:
        data = r.json().get("data", {})
        return True, data.get("user_name", "未知用户")
    return False, r.json().get("err_msg", "Cookie 无效")

def get_category_id(name):
    return CATEGORIES.get(name, CATEGORIES["技术"])

def recommend_tags(content="", keywords=""):
    """根据内容推荐标签（演示版，真实版接入 AI）"""
    cfg = load_config()
    hot = cfg["seo"]["hot_tags"]

    # 关键词匹配推荐
    content_lower = (content + keywords).lower()
    auto_tags = []
    tag_map = {
        "python": "Python", "javascript": "JavaScript", "typescript": "TypeScript",
        "react": "React", "vue": "Vue", "golang": "Go",
        "rust": "Rust", "docker": "Docker", "k8s": "Kubernetes",
        "ai": "AI", "gpt": "AI", "llm": "AI", "chatgpt": "AI",
        "github": "GitHub", "api": "API", "database": "数据库",
        "security": "安全", "performance": "性能优化",
        "tutorial": "教程", "实战": "实战", "guide": "教程",
    }
    for kw, tag in tag_map.items():
        if kw in content_lower and tag not in auto_tags:
            auto_tags.append(tag)

    # 补充热门标签
    limit = cfg["seo"]["tags_limit"]
    for tag in hot:
        if tag not in auto_tags and len(auto_tags) < limit:
            auto_tags.append(tag)

    return auto_tags[:limit]

def generate_summary(content, keywords=""):
    """AI 生成文章摘要（演示版）"""
    # 提取前 200 字作为摘要
    lines = [l.strip() for l in content.split("\n") if l.strip() and not l.startswith("#")]
    plain = " ".join(lines)[:200]
    if len(" ".join(lines)) > 200:
        plain += "..."
    return plain or "暂无摘要"

def publish_article(title, content, tags, category="技术", cover="", draft=False, cookie=None):
    """发布文章到掘金"""
    category_id = get_category_id(category)

    payload = {
        "title":         title,
        "html_content":  content,          # 富文本（直接发 Markdown 原文也可）
        "markdown_content": content,
        "tag_ids":       [],
        "category_id":   category_id,
        "cover_image":   cover or "",
        "status":        2 if draft else 1,  # 1=发布，2=草稿
    }

    r = requests.post(
        f"{JUEJIN_API}/content_api/v1/article",
        headers=headers(cookie),
        json=payload,
        timeout=20
    )

    result = r.json()
    if result.get("err_no") == 0:
        data = result.get("data", {})
        return True, {
            "article_id": data.get("article_id", ""),
            "url": f"https://juejin.cn/post/{data.get('article_id','')}",
            "title": title,
        }
    else:
        return False, result.get("err_msg", str(result))

def publish_from_file(filepath, tags=None, category=None, draft=False, cookie=None):
    """从 Markdown 文件发布"""
    with open(filepath, "r", encoding="utf-8") as f:
        content = f.read()

    # 提取 frontmatter
    title = os.path.basename(filepath).replace(".md", "")
    if content.startswith("---"):
        parts = content.split("---", 2)
        if len(parts) >= 3:
            fm = parts[1]
            body = parts[2].strip()
            for line in fm.split("\n"):
                if line.startswith("title:"):
                    title = line.split(":", 1)[1].strip().strip('"').strip("'")
                elif line.startswith("tags:"):
                    pass  # 标签从参数取
            content = body
    else:
        # 简单从标题行提取
        for line in content.split("\n"):
            if line.startswith("# "):
                title = line[2:].strip()
                break

    # 生成摘要
    summary = generate_summary(content)

    # 推荐标签
    recommended = recommend_tags(content, "")
    if tags:
        final_tags = tags.split(",") if isinstance(tags, str) else tags
    else:
        final_tags = recommended

    print(f"📝 标题: {title}")
    print(f"🏷️  标签: {final_tags}")
    print(f"📁 分类: {category or '技术'}")
    print(f"📋 摘要: {summary[:80]}...")

    ok, result = publish_article(
        title=title,
        content=content,
        tags=final_tags,
        category=category or "技术",
        draft=draft,
        cookie=cookie,
    )
    return ok, result

def post_to_web(title, content, tags, cookie=None):
    """通过网页 API 发布（备用方案）"""
    # 先获取 csrftoken
    r = requests.get(f"{JUEJIN_WEB}/editor", headers=headers(cookie), timeout=10)
    csrf = r.cookies.get("csrf_token", "")

    payload = {
        "title": title,
        "markdown_content": content,
        "tag_list": tags,
        "status": 1,
    }
    headers2 = headers(cookie)
    headers2["x-csrf-token"] = csrf

    r2 = requests.post(
        f"{JUEJIN_API}/content_api/v1/article",
        headers=headers2,
        json=payload,
        timeout=20
    )
    return r2.json()

def main():
    parser = argparse.ArgumentParser(description="掘金自动发帖器")
    parser.add_argument("--file", help="Markdown 文件路径")
    parser.add_argument("--title", help="文章标题")
    parser.add_argument("--content", help="文章内容（Markdown）")
    parser.add_argument("--tags", help="标签，逗号分隔，如: AI,GitHub,Python")
    parser.add_argument("--category", choices=list(CATEGORIES.keys()), default="技术", help="文章分类")
    parser.add_argument("--cover", help="封面图片 URL")
    parser.add_argument("--draft", action="store_true", help="仅保存为草稿")
    parser.add_argument("--cookie", default=COOKIE, help="掘金 Cookie（可设置 JUEJIN_COOKIE 环境变量）")
    parser.add_argument("--check-login", action="store_true", help="仅验证登录状态")
    parser.add_argument("--auto-tag", action="store_true", help="自动推荐标签")
    parser.add_argument("--ai-summary", action="store_true", help="AI 生成摘要")
    parser.add_argument("--stats", action="store_true", help="查看发布统计")
    parser.add_argument("--account-add", metavar="NAME", help="添加账号")
    parser.add_argument("--account-list", action="store_true", help="列出所有账号")
    args = parser.parse_args()

    if args.check_login:
        ok, msg = check_login(args.cookie)
        print(f"{'✅' if ok else '❌'} {msg}")
        sys.exit(0 if ok else 1)

    if args.account_list:
        cfg = load_config()
        accounts = cfg.get("accounts", {})
        if not accounts:
            print("暂无保存的账号")
        else:
            for name in accounts:
                print(f"  👤 {name}")
        sys.exit(0)

    if not args.cookie:
        print("❌ 请设置 JUEJIN_COOKIE 环境变量，或传 --cookie 参数")
        print("   浏览器登录掘金后：F12 → Application → Cookies → 复制 cookie 值")
        sys.exit(1)

    print("🤖 掘金自动发帖器 v1.0")
    ok, msg = check_login(args.cookie)
    if not ok:
        print(f"❌ 登录失败: {msg}")
        sys.exit(1)
    print(f"✅ 已登录: {msg}")

    if args.file:
        ok, result = publish_from_file(
            args.file,
            tags=args.tags,
            category=args.category,
            draft=args.draft,
            cookie=args.cookie,
        )
        if ok:
            print(f"\n✅ {'草稿已保存' if args.draft else '发布成功'}!")
            print(f"   链接: {result.get('url','?')}")
            print(f"   ID: {result.get('article_id','?')}")
        else:
            print(f"\n❌ 发布失败: {result}")
            sys.exit(1)
    elif args.title and args.content:
        tags = recommend_tags(args.content, args.tags or "")
        if args.tags:
            tags = args.tags.split(",")
        ok, result = publish_article(
            title=args.title,
            content=args.content,
            tags=tags,
            category=args.category,
            cover=args.cover,
            draft=args.draft,
            cookie=args.cookie,
        )
        if ok:
            print(f"\n✅ {'草稿已保存' if args.draft else '发布成功'}!")
            print(f"   链接: {result.get('url','?')}")
        else:
            print(f"\n❌ 发布失败: {result}")
            sys.exit(1)
    else:
        parser.print_help()

    print("\n💡 获取完整版（含 AI SEO 优化 + 自动配图 + 定时发布）：")
    print("   联系 Telegram @diquchaxun78_bot 购买 ¥39")

if __name__ == "__main__":
    main()
