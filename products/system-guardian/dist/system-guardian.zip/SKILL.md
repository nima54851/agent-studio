---
name: system-guardian
description: 系统监控与自动清理技能。当用户说"清理磁盘"、"系统监控"、"磁盘满了"、"内存告警"、"自动清理垃圾"、"监控服务器"、"运维巡检"、"服务器健康检查"、或需要定期检查服务器状态时触发。本技能自动监控 CPU/内存/磁盘/网络/进程状态，磁盘告警时自动清理（删除旧日志、清理缓存、清理大文件），支持微信/Telegram/钉钉告警，生成每日巡检报告（Markdown），并可接入 Prometheus/Grafana。适用于个人服务器、VPS、云服务器、AI Agent 运行环境等。
paid: true
price: ¥29 / $3.99 USD
payment: https://paypal.me/lingxiagent/299
payment_cn: 联系 Telegram @diquchaxun78_bot 或微信购买
version: 1.0.0
author: 灵犀
---
# System Guardian — 系统监控与自动清理

## 💰 付费说明

本技能为付费技能（¥29 / $3.99 USD，永久授权）。

**包含内容：**
- CPU / 内存 / 磁盘 / 网络 / 进程 全维度监控
- 磁盘自动清理（old logs、temp files、npm cache、docker 缓存）
- 微信 / Telegram / 钉钉 告警推送
- 每日自动巡检报告（Markdown）
- 大文件预警 + 自动清理规则
- Prometheus + Grafana 集成配置
- 阈值自定义（磁盘 80%/90%/95% 三档告警）

**获取方式：** [PayPal 付款](https://paypal.me/lingxiagent/299) 后联系 Telegram [@diquchaxun78_bot](https://t.me/diquchaxun78_bot) 发送付款截图获取完整技能包。

---

## 快速开始

### Step 1：安装依赖

```bash
pip install psutil requests schedule jinja2
```

### Step 2：运行健康检查

```bash
python3 system_guardian.py --check

# 详细输出
python3 system_guardian.py --check --verbose
```

### Step 3：自动清理

```bash
# 干跑模式（只显示会清理什么，不实际删除）
python3 system_guardian.py --clean --dry-run

# 执行清理
python3 system_guardian.py --clean
```

### Step 4：启动守护进程（后台常驻）

```bash
# 守护模式：每 30 分钟巡检一次
python3 system_guardian.py --daemon --interval 30

# 带告警
python3 system_guardian.py --daemon --alert-telegram --telegram-token "xxx" --telegram-chat "xxx"
```

---

## 监控维度

| 指标 | 告警阈值 | 动作 |
|---|---|---|
| 磁盘使用率 | > 85% 🟡 / > 95% 🔴 | 自动清理 |
| 内存使用率 | > 80% 🟡 / > 90% 🔴 | 推送告警 |
| CPU 使用率 | > 90% 🟡 / > 95% 🔴 | 推送告警 |
| 大文件 | 单文件 > 1GB | 记录日志 |
| 僵尸进程 | 存在 | 推送告警 |
| 服务进程 | 掉线 | 重启服务 |

---

## 清理规则

```json
{
  "clean_rules": [
    { "path": "/tmp",        "age_days": 7,  "pattern": "*",              "desc": "临时文件" },
    { "path": "/var/log",    "age_days": 14, "pattern": "*.log",          "desc": "旧日志" },
    { "path": "/root/.npm",  "age_days": 0,  "pattern": "*",              "desc": "npm 缓存", "action": "npm_cache" },
    { "path": "/root/.cache","age_days": 7,  "pattern": "*",              "desc": "pip/系统缓存" },
    { "path": "/var/cache",  "age_days": 7,  "pattern": "*",              "desc": "apt 缓存" }
  ],
  "thresholds": {
    "disk_warn": 85,
    "disk_critical": 95,
    "mem_warn": 80,
    "mem_critical": 90,
    "cpu_warn": 90,
    "big_file_mb": 500
  }
}
```

---

## 告警配置

### Telegram

```bash
export TELEGRAM_BOT_TOKEN="your_bot_token"
export TELEGRAM_CHAT_ID="your_chat_id"
python3 system_guardian.py --daemon --alert-telegram
```

### 钉钉

```bash
export DINGTALK_WEBHOOK="https://oapi.dingtalk.com/robot/send?access_token=xxx"
python3 system_guardian.py --daemon --alert-dingtalk
```

### 微信（企业微信）

```bash
export WXWORK_WEBHOOK="https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=xxx"
python3 system_guardian.py --daemon --alert-wxwork
```

---

## 巡检报告示例

```markdown
# 🛡️ System Guardian 巡检报告
## 2026-08-08 14:00 CST

## 📊 系统状态

| 指标 | 当前值 | 状态 |
|------|--------|------|
| 磁盘 | 36G / 40G (90%) | 🔴 告警 |
| 内存 | 1.5G / 3.6G (42%) | 🟢 正常 |
| CPU | 12% | 🟢 正常 |
| 负载 | 0.3 | 🟢 正常 |

## 🧹 清理记录

| 路径 | 释放空间 | 操作 |
|------|---------|------|
| /tmp/*.log | 1.2 GB | 已删除 |
| /root/.npm | 697 MB | 缓存清理 |
| /var/log/*.log | 320 MB | 归档删除 |

## ⚠️ 需要关注

- 🔴 磁盘使用率 90%，建议清理
- 🟡 磁盘空间 < 5GB，接近危险线

## 📈 历史趋势（7天）

[磁盘使用率图表略]

---
*🤖 System Guardian 自动生成 · 灵犀 AI*
```

---

## 定时任务（cron）

```bash
# 每小时巡检，每晚 2 点清理
0 * * * * python3 /path/to/system_guardian.py --check >> /var/log/guardian.log 2>&1
0 2 * * * python3 /path/to/system_guardian.py --clean >> /var/log/guardian_clean.log 2>&1
```

---

## 故障排除

**Q: 磁盘清理后仍然告警？**
→ 检查是否有大文件（如数据库、日志文件）持续写入，考虑日志轮转

**Q: 告警推送失败？**
→ 检查网络连通性，或用 `--alert-log` 写入本地日志文件作为备用

**Q: 守护进程如何停止？**
→ `pkill -f system_guardian.py` 或 `kill $(cat /tmp/guardian.pid)`

---

*版本 1.0.0 · 灵犀 AI · 2026-08*
