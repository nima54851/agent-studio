#!/usr/bin/env python3
"""
System Guardian — 系统监控与自动清理
自动巡检 CPU/内存/磁盘/网络，磁盘告警时自动清理
"""
import os, sys, json, argparse, time, glob, subprocess
from datetime import datetime, timezone, timedelta
from pathlib import Path

try:
    import psutil
except ImportError:
    print("❌ 需要 psutil: pip install psutil"); sys.exit(1)

DEFAULT_CONFIG = {
    "thresholds": {
        "disk_warn": 85,
        "disk_critical": 95,
        "mem_warn": 80,
        "mem_critical": 90,
        "cpu_warn": 90,
        "big_file_mb": 500,
    },
    "clean_rules": [
        {"path": "/tmp",          "age_days": 7,  "pattern": "*",        "desc": "临时文件"},
        {"path": "/root/.npm",    "age_days": 0,  "pattern": "*",        "desc": "npm 缓存", "action": "npm_cache"},
        {"path": "/root/.cache",  "age_days": 7,  "pattern": "*",        "desc": "pip/系统缓存"},
    ],
    "watch_processes": [],
    "alert_telegram": False,
    "alert_dingtalk": False,
}

def load_config():
    path = os.path.expanduser("~/.system_guardian_config.json")
    if os.path.exists(path):
        with open(path) as f:
            return json.load(f)
    return DEFAULT_CONFIG

def save_config(cfg):
    path = os.path.expanduser("~/.system_guardian_config.json")
    with open(path, "w") as f:
        json.dump(cfg, f, indent=2)

def get_disk_usage(path="/"):
    try:
        d = psutil.disk_usage(path)
        return {
            "total": d.total,
            "used": d.used,
            "free": d.free,
            "percent": d.percent,
            "total_gb": round(d.total / (1024**3), 1),
            "used_gb": round(d.used / (1024**3), 1),
            "free_gb": round(d.free / (1024**3), 1),
        }
    except:
        return {}

def get_memory():
    m = psutil.virtual_memory()
    return {
        "total": round(m.total / (1024**3), 2),
        "used": round(m.used / (1024**3), 2),
        "available": round(m.available / (1024**3), 2),
        "percent": m.percent,
    }

def get_cpu():
    return {
        "percent": psutil.cpu_percent(interval=1),
        "count": psutil.cpu_count(),
        "load": os.getloadavg() if hasattr(os, "getloadavg") else (0, 0, 0),
    }

def get_top_processes(n=10):
    procs = []
    for p in psutil.process_iter(["pid","name","cpu_percent","memory_percent","cmdline"]):
        try:
            info = p.info
            procs.append({
                "pid":    info["pid"],
                "name":   info["name"][:30] if info["name"] else "?",
                "cpu":    round(info["cpu_percent"] or 0, 1),
                "mem":    round(info["memory_percent"] or 0, 1),
                "cmd":    " ".join(info["cmdline"] or [])[:60],
            })
        except:
            continue
    return sorted(procs, key=lambda x: x["cpu"], reverse=True)[:n]

def find_large_files(threshold_mb=500, paths=None):
    """找大文件"""
    if paths is None:
        paths = ["/tmp", "/root/.cache", "/var/log"]
    large = []
    for base in paths:
        if not os.path.exists(base):
            continue
        try:
            for root, dirs, files in os.walk(base):
                for f in files:
                    fp = os.path.join(root, f)
                    try:
                        size = os.path.getsize(fp)
                        mb = size / (1024**2)
                        if mb >= threshold_mb:
                            large.append({
                                "path": fp,
                                "size_mb": round(mb, 1),
                                "mtime": datetime.fromtimestamp(os.path.getmtime(fp)).isoformat(),
                            })
                    except:
                        continue
        except:
            continue
    return sorted(large, key=lambda x: x["size_mb"], reverse=True)[:20]

def clean_by_rule(rule, dry_run=True):
    """按规则清理目录"""
    path = rule["path"]
    if not os.path.exists(path):
        return 0, []

    age_days = rule.get("age_days", 7)
    pattern  = rule.get("pattern", "*")
    action   = rule.get("action", "delete")

    freed = []
    size_freed = 0

    if action == "npm_cache":
        if not dry_run:
            subprocess.run(["npm", "cache", "clean", "--force"],
                          capture_output=True, timeout=30)
        freed.append(f"npm cache {'清理' if dry_run else '已清理'}")
        return 0, freed

    # 找匹配文件
    cutoff = time.time() - age_days * 86400
    try:
        for fp in glob.glob(os.path.join(path, pattern)):
            if not os.path.isfile(fp):
                continue
            mtime = os.path.getmtime(fp)
            if mtime < cutoff:
                size = os.path.getsize(fp)
                if not dry_run:
                    os.remove(fp)
                size_mb = round(size / 1024**2, 1)
                size_freed += size_mb
                freed.append(f"{os.path.basename(fp)} ({size_mb}MB)")
    except Exception as e:
        pass

    return size_freed, freed

def status_icon(pct, thresholds):
    if pct >= thresholds.get("disk_critical", 95):
        return "🔴", "critical"
    elif pct >= thresholds.get("disk_warn", 85):
        return "🟡", "warn"
    return "🟢", "ok"

def send_telegram(message):
    token = os.environ.get("TELEGRAM_BOT_TOKEN", "")
    chat_id = os.environ.get("TELEGRAM_CHAT_ID", "")
    if not token or not chat_id:
        return False, "Token 未设置"
    try:
        r = requests.post(
            f"https://api.telegram.org/bot{token}/sendMessage",
            json={"chat_id": chat_id, "text": message, "parse_mode": "HTML"},
            timeout=10
        )
        return r.status_code == 200, r.json()
    except Exception as e:
        return False, str(e)

def build_report(disk, mem, cpu, large_files, clean_results):
    lines = [
        f"# 🛡️ System Guardian 巡检报告",
        f"**时间：** {datetime.now(timezone(timedelta(hours=8))).strftime('%Y-%m-%d %H:%M')} CST",
        "",
        "## 📊 系统状态",
        "",
        "| 指标 | 数值 | 状态 |",
        "|------|------|------|",
    ]

    di, di_icon = status_icon(disk["percent"], DEFAULT_CONFIG["thresholds"])
    mi, _ = status_icon(mem["percent"], DEFAULT_CONFIG["thresholds"])
    ci, _ = status_icon(cpu["percent"], DEFAULT_CONFIG["thresholds"])

    lines.append(f"| 磁盘 | {disk['used_gb']}G / {disk['total_gb']}G ({disk['percent']:.0f}%) | {di} |")
    lines.append(f"| 内存 | {mem['used']}G / {mem['total']}G ({mem['percent']:.0f}%) | {mi} |")
    lines.append(f"| CPU  | {cpu['percent']:.0f}% | {ci} |")
    lines.append(f"| 负载 | {cpu['load'][0]:.2f} | 🟢 |" if cpu.get("load") else "| 负载 | — | 🟢 |")
    lines.append("")

    if large_files:
        lines += ["## ⚠️ 大文件", "", "| 文件 | 大小 | 修改时间 |", "|------|------|----------|"]
        for f in large_files[:10]:
            lines.append(f"| `{f['path']}` | {f['size_mb']} MB | {f['mtime'][:10]} |")
        lines.append("")

    if clean_results:
        lines += ["## 🧹 清理记录", ""]
        total = 0
        for rule_desc, size, files in clean_results:
            if size > 0:
                lines.append(f"- **{rule_desc}**：释放 {size:.1f} MB")
                total += size
        lines.append("")
        lines.append(f"**合计释放：{total:.1f} MB**\n")

    lines.append("---\n*🤖 System Guardian · 灵犀 AI*")
    return "\n".join(lines)

def main():
    parser = argparse.ArgumentParser(description="System Guardian — 系统监控与自动清理")
    parser.add_argument("--check", action="store_true", help="运行健康检查")
    parser.add_argument("--clean", action="store_true", help="执行清理")
    parser.add_argument("--dry-run", action="store_true", help="干跑模式（只显示，不删除）")
    parser.add_argument("--daemon", action="store_true", help="守护进程模式")
    parser.add_argument("--interval", type=int, default=30, help="守护模式巡检间隔（分钟）")
    parser.add_argument("--verbose", action="store_true", help="详细输出")
    parser.add_argument("--report", action="store_true", help="生成巡检报告")
    parser.add_argument("--alert-telegram", action="store_true", help="启用 Telegram 告警")
    parser.add_argument("--large-files", action="store_true", help="查找大文件")
    parser.add_argument("--config", help="配置文件路径")
    args = parser.parse_args()

    cfg = load_config()
    thresh = cfg.get("thresholds", DEFAULT_CONFIG["thresholds"])

    # 健康检查
    if args.check or args.report:
        print("🛡️ System Guardian 巡检中...")
        disk = get_disk_usage("/")
        mem  = get_memory()
        cpu  = get_cpu()
        top  = get_top_processes(5)

        di, di_icon = status_icon(disk["percent"], thresh)
        print(f"\n📊 系统状态")
        print(f"  磁盘 {di}  {disk['used_gb']}G / {disk['total_gb']}G ({disk['percent']:.0f}%)")
        print(f"  内存    {mem['used']}G / {mem['total']}G ({mem['percent']:.0f}%)")
        print(f"  CPU     {cpu['percent']:.0f}%")
        if cpu.get("load"):
            print(f"  负载    {cpu['load'][0]:.2f}")

        if args.verbose:
            print(f"\n🔥 CPU Top 进程")
            for p in top:
                print(f"  {p['name']} PID={p['pid']} CPU={p['cpu']}% MEM={p['mem']}%")

        if args.report:
            lf = find_large_files(thresh.get("big_file_mb", 500)) if args.large_files else []
            rep = build_report(disk, mem, cpu, lf, [])
            print("\n" + rep)
            with open("/tmp/guardian_report.md", "w") as f:
                f.write(rep)
            print("📄 报告已保存: /tmp/guardian_report.md")

    # 清理
    if args.clean:
        print("🧹 开始清理...")
        total_freed = 0
        results = []
        for rule in cfg.get("clean_rules", DEFAULT_CONFIG["clean_rules"]):
            size, files = clean_by_rule(rule, dry_run=args.dry_run)
            if files:
                print(f"  ✅ {rule['desc']}: 释放 {size:.1f} MB")
                results.append((rule["desc"], size, files))
                total_freed += size
            else:
                print(f"  ⬜ {rule['desc']}: 无需清理")
        print(f"\n{'🧪 干跑' if args.dry_run else '✅'}清理完成，共释放 {total_freed:.1f} MB")

    # 大文件查找
    if args.large_files:
        print("🔍 查找大文件...")
        lf = find_large_files(thresh.get("big_file_mb", 500))
        if not lf:
            print("  未发现超过阈值的大文件")
        for f in lf:
            print(f"  {f['size_mb']:>8.1f} MB  {f['path']}")

    # 守护进程
    if args.daemon:
        print(f"🛡️ 守护进程启动，每 {args.interval} 分钟巡检一次")
        print(f"   PID 文件: /tmp/guardian.pid")
        with open("/tmp/guardian.pid", "w") as f:
            f.write(str(os.getpid()))
        while True:
            try:
                disk = get_disk_usage("/")
                di, _ = status_icon(disk["percent"], thresh)
                now = datetime.now(timezone(timedelta(hours=8))).strftime("%H:%M")
                print(f"[{now}] 磁盘: {di} {disk['percent']:.0f}%")
                if args.alert_telegram and disk["percent"] >= thresh["disk_warn"]:
                    msg = f"🛡️ 磁盘告警：{disk['percent']:.0f}% / {disk['used_gb']}G / {disk['total_gb']}G"
                    ok, _ = send_telegram(msg)
                    if ok:
                        print(f"  📱 告警已发送")
            except Exception as e:
                print(f"  ⚠️ 巡检异常: {e}")
            time.sleep(args.interval * 60)

if __name__ == "__main__":
    main()
