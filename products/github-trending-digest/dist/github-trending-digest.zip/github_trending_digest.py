#!/usr/bin/env python3
"""
GitHub Trending Digest — 自动追踪 GitHub 热门项目 + AI 日报生成
支持 Python/JavaScript/Go/Rust/TypeScript 等多语言
"""
import os, sys, json, argparse, re, time
from datetime import datetime, timezone, timedelta

try:
    import requests
    from bs4 import BeautifulSoup
except ImportError:
    print("❌ 缺少依赖: pip install requests beautifulsoup4")
    sys.exit(1)

DEFAULT_LANGS = ["python", "javascript", "go", "rust", "typescript"]
GITHUB_TOKEN  = os.environ.get("GITHUB_TOKEN", "")
AI_API_KEY    = os.environ.get("AI_API_KEY", "")
CONFIG_PATH   = "config.json"

def load_config():
    if os.path.exists(CONFIG_PATH):
        with open(CONFIG_PATH) as f:
            return json.load(f)
    return {
        "languages": DEFAULT_LANGS,
        "max_projects_per_lang": 20,
        "output": {"format": "markdown", "path": "REPORT.md"},
        "ai_model": "claude",
        "trend_compare": True,
    }

def fetch_trending(lang="python", since="daily"):
    """抓取 GitHub Trending 页面"""
    url = f"https://github.com/trending/{lang}?since={since}"
    headers = {
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36",
        "Accept-Language": "en-US,en;q=0.9",
    }
    if GITHUB_TOKEN:
        headers["Authorization"] = f"token {GITHUB_TOKEN}"

    r = requests.get(url, headers=headers, timeout=30)
    r.raise_for_status()
    return r.text

def parse_trending(html, lang):
    """解析 Trending 页面，提取项目信息"""
    soup = BeautifulSoup(html, "html.parser")
    articles = soup.select("article.Box-row")
    projects = []

    for article in articles[:25]:
        try:
            a_tag = article.select_one("h2 a")
            if not a_tag:
                continue
            href = a_tag.get("href", "")
            name = href.lstrip("/")
            url  = f"https://github.com/{name}"

            # 描述
            desc_tag = article.select_one("p")
            description = desc_tag.get_text(strip=True) if desc_tag else ""

            # 编程语言
            lang_tag = article.select_one('[itemprop="programmingLanguage"]')
            language = lang_tag.get_text(strip=True) if lang_tag else lang

            # Star / Fork
            stars = article.select_one('a[href$="/stargazers"]')
            forks = article.select_one('a[href$="/network/members"]')
            stars_text = stars.get_text(strip=True).replace(",", "") if stars else "0"
            forks_text = forks.get_text(strip=True).replace(",", "") if forks else "0"

            # 今日新增（Trending 页面有显示）
            today_stars = ""
            star_span = article.select_one("span.d-inline-block.float-sm-right")
            if star_span:
                today_stars = star_span.get_text(strip=True).replace("stars today", "").strip()

            projects.append({
                "name": name,
                "url": url,
                "description": description,
                "language": language,
                "stars": parse_num(stars_text),
                "forks": parse_num(forks_text),
                "today_stars": today_stars,
            })
        except Exception:
            continue

    return projects

def parse_num(s):
    s = s.strip()
    if not s:
        return 0
    multipliers = {"k": 1000, "K": 1000, "m": 1000000, "M": 1000000}
    try:
        if s[-1] in multipliers:
            return int(float(s[:-1]) * multipliers[s[-1]])
        return int(s)
    except:
        return 0

def get_stars_today(stars_str):
    """从 '1,234' 提取数字"""
    try:
        return int(stars_str.replace(",", ""))
    except:
        return 0

def ai_analyze_project(projects, model="claude"):
    """用 AI 对项目进行分类和提炼（演示版）"""
    for p in projects:
        # 简单关键词分类（真实版接 AI API）
        desc = p["description"].lower()
        if any(k in desc for k in ["llm", "ai", "gpt", "claude", "chat", "model"]):
            p["tag"] = "🤖 AI/ML"
        elif any(k in desc for k in ["api", "rest", "grpc", "http"]):
            p["tag"] = "🔌 API/网络"
        elif any(k in desc for k in ["web", "frontend", "react", "vue", "ui"]):
            p["tag"] = "🌐 前端"
        elif any(k in desc for k in ["docker", "k8s", "kubernetes", "cloud", "deploy"]):
            p["tag"] = "☁️ DevOps/云"
        elif any(k in desc for k in ["security", "auth", "crypto", "encrypt"]):
            p["tag"] = "🛡️ 安全"
        elif any(k in desc for k in ["database", "sql", "mongo", "redis", "db"]):
            p["tag"] = "🗄️ 数据库"
        else:
            p["tag"] = "🛠️ 工具/其他"

        # 热度评级
        stars = p["stars"]
        if stars >= 10000:
            p["heat"] = "🔥🔥🔥🔥🔥"
        elif stars >= 5000:
            p["heat"] = "🔥🔥🔥🔥"
        elif stars >= 1000:
            p["heat"] = "🔥🔥🔥"
        elif stars >= 500:
            p["heat"] = "🔥🔥"
        else:
            p["heat"] = "🔥"

    return projects

def build_markdown_report(results, date_str):
    """构建 Markdown 日报"""
    lines = [
        f"# 🤖 GitHub Trending 日报 — {date_str}",
        "",
        f"**追踪语言：** {', '.join(results.keys())}",
        f"**生成时间：** {datetime.now(timezone(timedelta(hours=8))).strftime('%Y-%m-%d %H:%M')} CST",
        "",
        "---",
        "",
    ]

    for lang, projects in results.items():
        if not projects:
            continue
        projects = ai_analyze_project(projects)

        total_stars = sum(p["stars"] for p in projects)
        top = sorted(projects, key=lambda x: x["stars"], reverse=True)[0]

        lines += [
            f"## 🐍 {lang.upper()} · 今日热门",
            "",
            f"共 {len(projects)} 个项目 · 总 Stars：{format_num(total_stars)} ⭐",
            f"🏆 本语言冠军：[{top['name']}]({top['url']}) (+{top.get('today_stars','?')} ⭐ 今天)",
            "",
        ]

        # 按 tag 分组
        by_tag = {}
        for p in projects:
            by_tag.setdefault(p["tag"], []).append(p)

        for tag, tag_projects in sorted(by_tag.items(), key=lambda x: -sum(p["stars"] for p in x[1])):
            tag_projects.sort(key=lambda x: x["stars"], reverse=True)
            lines.append(f"### {tag}（{len(tag_projects)} 个）")
            lines.append("")
            for p in tag_projects[:5]:
                stars_fmt = format_num(p["stars"])
                today = f"+{p.get('today_stars','?')}⭐今天" if p.get("today_stars") else ""
                lines.append(
                    f"- **[{p['name']}]({p['url']})** {p['heat']}  "
                    f"⭐ {stars_fmt} {today}"
                )
                if p["description"]:
                    lines.append(f"  {p['description'][:80]}")
            lines.append("")

        lines.append("---\n")

    lines += [
        "## 📊 数据来源",
        "",
        "数据来源：[github.com/trending](https://github.com/trending)",
        "由 [GitHub Trending Digest](https://github.com/nima54851/agent-studio) 自动生成",
        "",
        "---",
        "*🤖 由 灵犀 AI 日报机器人 自动生成 · GitHub Trending Digest*",
    ]

    return "\n".join(lines)

def build_json_report(results):
    return json.dumps({
        "date": datetime.now(timezone(timedelta(hours=8))).isoformat(),
        "languages": list(results.keys()),
        "projects": results,
        "total_projects": sum(len(v) for v in results.values()),
    }, ensure_ascii=False, indent=2)

def format_num(n):
    if n >= 1000000:
        return f"{n/1000000:.1f}M"
    elif n >= 1000:
        return f"{n/1000:.1f}k"
    return str(n)

def main():
    parser = argparse.ArgumentParser(description="GitHub Trending Digest")
    parser.add_argument("--lang", default="python", help="编程语言，如 python, javascript, go, rust, typescript（逗号分隔多语言）")
    parser.add_argument("--all-languages", action="store_true", help="抓取所有语言")
    parser.add_argument("--since", default="daily", choices=["daily","weekly","monthly"])
    parser.add_argument("--format", default="markdown", choices=["markdown","html","json"])
    parser.add_argument("--output", default="REPORT.md", help="输出文件路径")
    parser.add_argument("--no-ai", action="store_true", help="跳过 AI 分析")
    parser.add_argument("--compare", action="store_true", help="与昨日数据对比")
    parser.add_argument("--webhook", help="推送报告到 Webhook URL")
    parser.add_argument("--email", help="发送到邮箱")
    parser.add_argument("--config", default=CONFIG_PATH, help="配置文件路径")
    args = parser.parse_args()

    cfg = load_config()
    langs = []
    if args.all_languages:
        langs = DEFAULT_LANGS
    elif args.lang:
        langs = [l.strip() for l in args.lang.split(",")]
    else:
        langs = cfg.get("languages", DEFAULT_LANGS)

    date_str = datetime.now(timezone(timedelta(hours=8))).strftime("%Y-%m-%d")
    print(f"🤖 GitHub Trending Digest — {date_str}")
    print(f"   语言: {', '.join(langs)}")

    results = {}
    for lang in langs:
        print(f"📡 抓取 {lang}...", end=" ", flush=True)
        try:
            html = fetch_trending(lang, args.since)
            projects = parse_trending(html, lang)
            results[lang] = projects
            print(f"✅ {len(projects)} 个项目")
        except Exception as e:
            print(f"❌ {e}")
            results[lang] = []

    if args.format == "json":
        output = build_json_report(results)
    else:
        output = build_markdown_report(results, date_str)

    # 保存文件
    with open(args.output, "w", encoding="utf-8") as f:
        f.write(output)
    print(f"\n✅ 报告已保存: {args.output}")
    print(f"   共 {sum(len(v) for v in results.values())} 个项目")

    # Webhook 推送
    if args.webhook:
        try:
            r = requests.post(args.webhook, json={"content": output[:1800]}, timeout=10)
            print(f"✅ 已推送到 Webhook ({r.status_code})")
        except Exception as e:
            print(f"⚠️ Webhook 推送失败: {e}")

    print("\n💡 获取完整版（含 AI 智能分析 + 自动推送）：")
    print("   联系 Telegram @diquchaxun78_bot 购买 ¥29")

if __name__ == "__main__":
    main()
