---
name: github-trending-digest
description: GitHub Trending 追踪与 AI 日报生成技能。当用户说"生成日报"、"GitHub Trending 报告"、"追踪热门项目"、"今日 GitHub"、"AI 发展趋势"、"周报"、"项目热度排行"、或需要定期汇总 GitHub 热门项目时触发。本技能自动抓取 GitHub Trending 页面，按语言/主题过滤，用 AI 生成结构化日报（Markdown/HTML/JSON），支持邮件/Webhook 推送和 GitHub Actions 定时任务。适用于开发者保持技术敏感度、技术团队 Leader 做技术选型、内容创作者寻找选题。
paid: true
price: ¥29 / $3.99 USD
payment: https://paypal.me/lingxiagent/299
payment_cn: 联系 Telegram @diquchaxun78_bot 或微信购买
version: 1.0.0
author: 灵犀
---
# GitHub Trending Digest — GitHub 热门项目追踪日报

## 💰 付费说明

本技能为付费技能（¥29 / $3.99 USD，永久授权）。

**包含内容：**
- GitHub Trending 自动抓取（支持所有编程语言）
- AI 驱动的项目分析 + 标签分类
- 多格式日报输出（Markdown / HTML / Email）
- Webhook / 邮件自动推送
- GitHub Actions 定时任务配置（北京时区 09:00）
- 趋势对比（与昨日/上周数据环比）

**获取方式：** [PayPal 付款](https://paypal.me/lingxiagent/299) 后联系 Telegram [@diquchaxun78_bot](https://t.me/diquchaxun78_bot) 发送付款截图获取完整技能包。

---

## 快速开始

### Step 1：安装依赖

```bash
pip install requests beautifulsoup4 jinja2 schedule
```

### Step 2：生成今日日报

```bash
python3 github_trending_digest.py --lang python --days 1

# 全语言日报
python3 github_trending_digest.py --all-languages

# 指定输出格式
python3 github_trending_digest.py --lang javascript --format html --output today.html
```

### Step 3：定时任务（GitHub Actions）

```yaml
# .github/workflows/trending-digest.yml
name: GitHub Trending Daily
on:
  schedule:
    - cron: '0 1 * * *'  # 北京时间 09:00
  workflow_dispatch:       # 也可手动触发

jobs:
  digest:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: 生成日报
        run: |
          python3 github_trending_digest.py \
            --lang python,javascript,go \
            --format markdown \
            --output REPORT.md
      - name: 提交日报
        run: |
          git config user.email "bot@lingxi.ai"
          git config user.name "灵犀日报机器人"
          git add REPORT.md
          git commit -m "🤖 $(date +%Y-%m-%d) GitHub Trending 日报"
          git push
```

---

## 核心功能

### 📡 数据采集

| 数据源 | 内容 | 频率 |
|---|---|---|
| GitHub Trending | 今日热门项目排行 | 每日 |
| GitHub API | Star 数变化、项目详情 | 实时 |
| AI 分析 | 项目标签、功能分类、技术栈提炼 | 每次生成 |

### 🤖 AI 日报内容

```markdown
# 🤖 GitHub Trending 日报 — 2026-08-08

## 📊 今日概览
- 新上榜项目：23 个（Python 7 / JS 6 / Go 4 / Rust 3 / 其他 3）
- 总 Star 增长：+4,821 ⭐
- 最热项目：lobehub/lobe-chat (+312 ⭐/天)

## 🔥 今日重点

### 🏆 本日最佳项目
**lobehub/lobe-chat** — 私密部署的 AI ChatGPT/Claude Web UI
⭐ 12.4k · Python · MIT License
💡 亮点：支持 12+ 模型、自托管、多用户、无审查

### 🔥 热门框架
- **Pynee**: Python AI Agent 框架（+180⭐）
- **FastAPI-MCP**: FastAPI + Model Context Protocol 集成

## 📈 趋势分析

| 语言 | 今日新项目 | 热度指数 | 趋势 |
|------|-----------|---------|------|
| Python | 7 | ⭐⭐⭐⭐ | ↑ 上升 |
| JavaScript | 6 | ⭐⭐⭐ | → 持平 |
| Go | 4 | ⭐⭐⭐⭐ | ↑ 上升 |
```

---

## 配置项（config.json）

```json
{
  "languages": ["python", "javascript", "go", "rust", "typescript"],
  "date_range": "daily",
  "max_projects_per_lang": 20,
  "ai_model": "claude",
  "output": {
    "format": "markdown",
    "path": "REPORT.md",
    "auto_commit": true
  },
  "push": {
    "enabled": false,
    "webhook_url": "",
    "email_to": ""
  },
  "trend_compare": true,
  "github_actions_cron": "0 1 * * *"
}
```

---

## 使用场景

| 场景 | 命令 |
|---|---|
| Python 项目日报 | `--lang python` |
| 多语言对比 | `--lang python,javascript,go,rust` |
| HTML 格式（内嵌样式） | `--format html --output report.html` |
| JSON 格式（供程序使用） | `--format json` |
| 推送到钉钉/飞书 | `--webhook https://oapi.dingtalk.com/...` |
| 发邮件 | `--email report@example.com` |
| 与昨日对比 | `--compare` |
| 手动触发（GitHub Actions） | `--workflow-dispatch` |

---

## AI 分析维度

每个项目自动分析：
- **技术栈**：语言、框架、关键依赖
- **功能分类**：AI/工具/应用/库/DevOps/安全
- **适用场景**：谁应该关注这个项目
- **热度评级**：🔥🔥🔥🔥🔥
- **收藏价值**：值得 star / 值得关注 / 普通

---

## 定时任务设置

### GitHub Actions（北京时区）

```bash
# 在仓库根目录创建
mkdir -p .github/workflows
# 放入 trending-digest.yml（见上方）
```

### 本地 Crontab

```bash
# 每天早上 9 点运行
0 9 * * * cd /path/to/repo && python3 github_trending_digest.py --lang python --output REPORT.md >> /var/log/trending.log 2>&1
```

---

## 故障排除

**Q: 抓不到数据（网络超时）？**
→ GitHub Trending 有反爬，建议加 `--user-agent` 或用 GitHub API 替代

**Q: AI 分析失败？**
→ 检查 AI_API_KEY 环境变量，或用 `--no-ai` 跳过 AI 分析

**Q: 定时任务没触发？**
→ 检查 GitHub Actions 的 cron 时区（GitHub 用 UTC，需-8小时）

---

*版本 1.0.0 · 灵犀 AI · 2026-08*
