---
name: github-ai-reviewer
description: AI 驱动的 GitHub PR 审查技能。当用户要求"审查 PR"、"Review PR"、"分析代码质量"、"给 PR 打分"、"检查安全漏洞"、"优化代码"、或主动识别到需要代码审查的场景时触发。本技能连接 GitHub API + AI 模型，对 PR 进行多维度分析（安全性、性能、可维护性、逻辑正确性），生成结构化审查报告并自动评论 PR。适用于 Claude Code、Cursor、 Windsurf、Codex 等 Agent。支持 GitHub 个人仓库和 GitHub Actions CI/CD 集成。适合开发者、Tech Lead、Code Review 文化团队使用。
paid: true
price: ¥49 / $6.99 USD
payment: https://paypal.me/lingxiagent/699
payment_cn: 联系 Telegram @diquchaxun78_bot 或微信购买
version: 1.0.0
author: 灵犀
---
# GitHub AI Reviewer — AI PR 审查技能

## 💰 付费说明

本技能为付费技能（¥49 / $6.99 USD，永久授权）。

**包含内容：**
- 多维度 AI 代码审查（安全/性能/可维护性/逻辑/测试）
- 自动生成结构化审查报告
- GitHub PR 自动评论（需 token）
- 支持 Claude / GPT-4 / Gemini 等主流模型
- 附赠 CI/CD 集成指南

**获取方式：** [PayPal 付款](https://paypal.me/lingxiagent/699) 后联系 Telegram [@diquchaxun78_bot](https://t.me/diquchaxun78_bot) 发送付款截图获取完整技能包。

---

## 快速开始

### Step 1：配置 GitHub Token

```bash
export GITHUB_TOKEN="ghp_xxxx"   # 需要 repo 权限
```

### Step 2：分析单个 PR

```bash
# 语法
python3 github_ai_reviewer.py --repo owner/repo --pr 42 --model claude

# 示例
python3 github_ai_reviewer.py --repo myname/myapp --pr 42 --model claude
```

### Step 3：批量审查多个 PR

```bash
python3 github_ai_reviewer.py --repo myname/myapp --batch --since "7 days ago"
```

### Step 4：集成 GitHub Actions（自动审查）

```bash
# 在仓库 .github/workflows/ai-review.yml 加入：
- name: AI Code Review
  uses: ./
  with:
    github_token: ${{ secrets.GITHUB_TOKEN }}
    model: claude
```

---

## 核心功能

### 🔍 多维度审查

| 维度 | 检查内容 | 严重程度 |
|---|---|---|
| 🛡️ 安全性 | SQL注入、XSS、硬编码密钥、不安全依赖 | 🔴 高 |
| ⚡ 性能 | N+1查询、内存泄漏、无效索引、同步阻塞 | 🟡 中 |
| 🏗️ 可维护性 | 函数过长、重复代码、命名不规范、缺少注释 | 🟡 中 |
| ✅ 逻辑正确性 | 边界条件、空指针、并发竞争、逻辑漏洞 | 🔴 高 |
| 🧪 测试覆盖 | 单元测试缺失、覆盖率低、mock 使用不当 | 🟢 低 |

### 📊 审查报告格式

```json
{
  "pr": "#42 add user auth module",
  "overall_score": 7.2,
  "dimensions": {
    "security":    { "score": 6.5, "issues": 3, "critical": 1 },
    "performance":  { "score": 7.0, "issues": 2, "critical": 0 },
    "maintainability": { "score": 7.5, "issues": 4, "critical": 0 },
    "correctness":  { "score": 7.8, "issues": 1, "critical": 0 },
    "tests":        { "score": 6.0, "issues": 2, "critical": 0 }
  },
  "summary": "PR 整体质量良好，建议修复 1 个安全问题后合并。",
  "recommendation": "APPROVE with suggestions"
}
```

---

## 工作流程

```
用户请求审查
    ↓
获取 PR diff + 文件列表
    ↓
对每个文件执行 AI 分析（分块处理避免超限）
    ↓
汇总维度评分 + 生成建议
    ↓
写入审查报告（本地 + 可选 GitHub PR 评论）
    ↓
返回结构化结果给用户
```

---

## 配置文件（config.json）

```json
{
  "github_token": "${GITHUB_TOKEN}",
  "default_model": "claude",
  "models": {
    "claude":  { "provider": "anthropic", "model": "claude-sonnet-4-20250514" },
    "gpt4":    { "provider": "openai",   "model": "gpt-4o" },
    "gemini":  { "provider": "google",    "model": "gemini-2.5-pro" }
  },
  "review_settings": {
    "max_files_per_run": 20,
    "max_tokens_per_file": 4000,
    "auto_comment": false,
    "severity_threshold": "medium"
  },
  "excluded_paths": ["node_modules/", "dist/", "build/", ".git/"]
}
```

---

## 常见使用场景

| 场景 | 命令 |
|---|---|
| 审查最新 PR | `--pr 42` |
| 审查最近 7 天的所有 PR | `--batch --since "7 days ago"` |
| 只看安全问题 | `--filter security` |
| 审查并自动评论 PR | `--auto-comment` |
| 输出 Markdown 报告 | `--format markdown --output review.md` |
| 集成 GitHub Actions | `--github-actions` |

---

## 依赖

```
requests
anthropic / openai / google-generativeai（至少安装一个）
PyJWT
```

---

## 故障排除

**Q: 报 404 错误？**
→ 检查 `GITHUB_TOKEN` 是否有 `repo` 权限，仓库是否公开

**Q: AI 模型调用失败？**
→ 确认 API Key 已正确配置，或切换其他模型 `--model gpt4`

**Q: PR 文件太多超限？**
→ 用 `--max-files 10` 限制每次审查的文件数

**Q: 审查太慢？**
→ 用 `--parallel` 启用并行分析（需要配置多个 API Key）

---

*版本 1.0.0 · 灵犀 AI · 2026-08*
