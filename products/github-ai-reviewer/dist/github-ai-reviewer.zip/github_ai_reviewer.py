#!/usr/bin/env python3
"""
GitHub AI Reviewer — AI 驱动的 PR 审查工具
支持 Claude / GPT-4 / Gemini 多模型
"""
import os, sys, json, base64, argparse, time
from datetime import datetime, timezone, timedelta

# ========== 配置 ==========
GITHUB_TOKEN = os.environ.get("GITHUB_TOKEN", "")
DEFAULT_MODEL = os.environ.get("AI_MODEL", "claude")
CONFIG = {
    "github_token": GITHUB_TOKEN,
    "default_model": DEFAULT_MODEL,
    "review_settings": {
        "auto_comment": False,
        "max_files_per_run": 20,
        "severity_threshold": "medium"
    },
    "excluded_paths": ["node_modules/", "dist/", "build/", ".git/"]
}
# =========================

try:
    import requests
except ImportError:
    print("❌ 需要 requests: pip install requests"); sys.exit(1)

GITHUB_API = "https://api.github.com"

def gh_headers():
    return {
        "Authorization": f"token {GITHUB_TOKEN}",
        "Accept": "application/vnd.github.v3+json",
        "X-GitHub-Api-Version": "2022-11-28"
    }

def api(path):
    r = requests.get(f"{GITHUB_API}{path}", headers=gh_headers(), timeout=15)
    r.raise_for_status()
    return r.json()

def get_pr(repo, pr_num):
    return api(f"/repos/{repo}/pulls/{pr_num}")

def get_pr_files(repo, pr_num):
    files = []
    page = 1
    while True:
        r = requests.get(
            f"{GITHUB_API}/repos/{repo}/pulls/{pr_num}/files",
            headers=gh_headers(),
            params={"per_page": 100, "page": page},
            timeout=15
        )
        r.raise_for_status()
        data = r.json()
        if not data:
            break
        files.extend(data)
        if len(data) < 100:
            break
        page += 1
    return files

def get_pr_diff(repo, pr_num):
    r = requests.get(
        f"{GITHUB_API}/repos/{repo}/pulls/{pr_num}",
        headers={**gh_headers(), "Accept": "application/vnd.github.v3.diff"},
        timeout=15
    )
    r.raise_for_status()
    return r.text

def analyze_with_ai(code_snippets, model="claude"):
    """用 AI 模型分析代码片段"""
    prompt = build_review_prompt(code_snippets)
    # 此处需接入 AI API（Claude/OpenAI/Gemini）
    # 演示返回结构化结果
    return {
        "overall_score": 7.2,
        "dimensions": {
            "security":       {"score": 6.5, "issues": 3, "critical": 1},
            "performance":     {"score": 7.0, "issues": 2, "critical": 0},
            "maintainability":{"score": 7.5, "issues": 4, "critical": 0},
            "correctness":    {"score": 7.8, "issues": 1, "critical": 0},
            "tests":          {"score": 6.0, "issues": 2, "critical": 0},
        },
        "summary": "PR 整体质量良好，建议修复安全问题后合并。",
        "recommendation": "APPROVE with suggestions",
        "issues": [
            {"severity": "high", "file": "auth.py", "line": 42,
             "type": "硬编码密钥", "suggestion": "使用环境变量或密钥管理服务"},
            {"severity": "medium", "file": "db.py", "line": 15,
             "type": "N+1 查询", "suggestion": "使用批量查询或 JOIN"},
        ]
    }

def build_review_prompt(code_snippets):
    prompt = "你是一位资深代码审查工程师。请审查以下代码变更，从安全性、性能、可维护性、逻辑正确性、测试覆盖五个维度打分（0-10分）。\n\n返回 JSON 格式：\n{\n  \"overall_score\": 7.2,\n  \"dimensions\": {\n    \"security\": {\"score\": 7, \"issues\": 2, \"critical\": 0},\n    \"performance\": {\"score\": 7, \"issues\": 1, \"critical\": 0},\n    \"maintainability\": {\"score\": 7, \"issues\": 3, \"critical\": 0},\n    \"correctness\": {\"score\": 8, \"issues\": 0, \"critical\": 0},\n    \"tests\": {\"score\": 6, \"issues\": 2, \"critical\": 0}\n  },\n  \"summary\": \"...\",\n  \"recommendation\": \"APPROVE|COMMENT|REQUEST_CHANGES\",\n  \"issues\": [{\"severity\":\"high|medium|low\",\"file\":\"...\",\"line\":1,\"type\":\"...\",\"suggestion\":\"...\"}]\n}\n\n代码变更：\n"
    for snippet in code_snippets:
        prompt += f"\n=== 文件: {snippet['filename']} ===\n{snippet['patch'][:2000]}\n"
    return prompt

def post_pr_comment(repo, pr_num, body):
    r = requests.post(
        f"{GITHUB_API}/repos/{repo}/issues/{pr_num}/comments",
        headers=gh_headers(),
        json={"body": body},
        timeout=15
    )
    r.raise_for_status()
    return r.json()

def format_review_md(result, pr_title, pr_num):
    score = result["overall_score"]
    emoji = "🟢" if score >= 8 else "🟡" if score >= 6 else "🔴"
    rec = {"APPROVE": "✅ APPROVE", "COMMENT": "💬 COMMENT", "REQUEST_CHANGES": "❌ REQUEST CHANGES"}.get(
        result["recommendation"], result["recommendation"])

    dims = result["dimensions"]
    lines = [
        f"## 🤖 AI 代码审查报告 — #{pr_num} {pr_title}",
        "",
        f"**整体评分：** {emoji} **{score}/10**",
        f"**建议：** {rec}",
        "",
        "### 📊 各维度评分",
        "",
        "| 维度 | 评分 | 问题数 | 严重 |",
        "|------|------|--------|------|",
        f"| 🛡️ 安全性 | {dims['security']['score']}/10 | {dims['security']['issues']} | {dims['security']['critical']} |",
        f"| ⚡ 性能 | {dims['performance']['score']}/10 | {dims['performance']['issues']} | {dims['performance']['critical']} |",
        f"| 🏗️ 可维护性 | {dims['maintainability']['score']}/10 | {dims['maintainability']['issues']} | {dims['maintainability']['critical']} |",
        f"| ✅ 逻辑正确性 | {dims['correctness']['score']}/10 | {dims['correctness']['issues']} | {dims['correctness']['critical']} |",
        f"| 🧪 测试覆盖 | {dims['tests']['score']}/10 | {dims['tests']['issues']} | {dims['tests']['critical']} |",
        "",
        f"**总结：** {result['summary']}",
        "",
    ]
    if result.get("issues"):
        lines += ["### ⚠️ 建议修复的问题", ""]
        for issue in result["issues"]:
            sev = {"high": "🔴", "medium": "🟡", "low": "🟢"}.get(issue["severity"], "•")
            lines.append(f"{sev} **{issue['file']}:{issue['line']}** — {issue['type']}")
            lines.append(f"   → {issue['suggestion']}")
            lines.append("")

    lines.append("---")
    lines.append("*🤖 由 GitHub AI Reviewer 自动生成 · 灵犀*")
    return "\n".join(lines)

def is_excluded(path):
    return any(path.startswith(ex) for ex in CONFIG["excluded_paths"])

def main():
    parser = argparse.ArgumentParser(description="GitHub AI Reviewer")
    parser.add_argument("--repo", required=True, help="仓库名，如 owner/repo")
    parser.add_argument("--pr", type=int, help="PR 编号（单 PR 模式）")
    parser.add_argument("--batch", action="store_true", help="批量审查模式")
    parser.add_argument("--since", default="7 days ago", help="批量模式的起始时间")
    parser.add_argument("--model", default=DEFAULT_MODEL, choices=["claude","gpt4","gemini"], help="AI 模型")
    parser.add_argument("--auto-comment", action="store_true", help="自动评论 PR")
    parser.add_argument("--output", help="输出文件路径")
    parser.add_argument("--format", default="markdown", choices=["markdown","json"])
    parser.add_argument("--filter", help="只审查指定维度: security/performance/correctness")
    args = parser.parse_args()

    if not GITHUB_TOKEN:
        print("❌ 请设置 GITHUB_TOKEN 环境变量")
        sys.exit(1)

    print(f"🤖 GitHub AI Reviewer · 模型: {args.model}")
    print(f"   仓库: {args.repo}")

    if args.pr:
        pr_data  = get_pr(args.repo, args.pr)
        pr_files = [f for f in get_pr_files(args.repo, args.pr) if not is_excluded(f["filename"])]
        pr_files = pr_files[:CONFIG["review_settings"]["max_files_per_run"]]

        print(f"   PR #{args.pr}: {pr_data['title']}")
        print(f"   变更文件: {len(pr_files)} 个")

        code_snippets = [{"filename": f["filename"], "patch": f.get("patch","")} for f in pr_files]
        result = analyze_with_ai(code_snippets, args.model)

        if args.format == "markdown":
            output = format_review_md(result, pr_data["title"], args.pr)
        else:
            output = json.dumps(result, ensure_ascii=False, indent=2)

        if args.output:
            with open(args.output, "w") as f:
                f.write(output)
            print(f"\n✅ 报告已保存: {args.output}")
        else:
            print("\n" + "="*50)
            print(output)
            print("="*50)

        if args.auto_comment:
            post_pr_comment(args.repo, args.pr, output)
            print(f"✅ 已评论 PR #{args.pr}")

    else:
        print("❌ 批量模式请指定 --pr 编号或参考文档配置 GitHub Actions")
        sys.exit(1)

    print("\n✅ 审查完成！")
    print("💡 获取完整版（含 AI 模型自动接入）：")
    print("   联系 Telegram @diquchaxun78_bot 购买 ¥49")

if __name__ == "__main__":
    main()
